#pragma once
void Init_Light();
void Init_Material();
void ApplyLight(float theta);
