#include <windows.h>
#include <gl/gl.h>
#include <stdio.h>
#include <stdlib.h>
#include "Texture.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb-master/stb_image.h"
#include <iostream>
using namespace std;

void LoadTextur(char *filename, GLuint *textureID, GLfloat swarp, GLfloat twarp, GLfloat filter){

//glPushMatrix();//tcnt - кол-во каналов
int twidth, thight, tcnt; //переменные ширины, высоты,
unsigned char *data=stbi_load(filename,&twidth,&thight,&tcnt,0);
// в поле filename прописывается имя
//файла “image.png”, а файл хранится в
//директории проекта
//GL_REPEAT,GL_REPEAT,GL_NEAREST
glGenTextures(1, textureID); //генерация текстуры
glBindTexture(GL_TEXTURE_2D, *textureID);
glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,swarp);//если координаты текстуры отличаются от координат примитива // по x //настройки
glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,twarp);//по y
glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,filter);//если размер текстуры и размер примитива отличаются //растяжение
glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,filter);//сжатие
glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, twidth, thight,
0, tcnt == 4 ? GL_RGBA : GL_RGB, GL_UNSIGNED_BYTE, data);

glBindTexture(GL_TEXTURE_2D, 0); //задание текстуры//чтобы эту текстура больше не зтрагивалась
stbi_image_free(data); //освобождение буфера
//glPopMatrix();

}

void ShowBackround(GLuint textureID,int num,float* svertix,float* TexCord){
//glPushMatrix();

glEnable(GL_TEXTURE_2D); //разрешение использования
//текстуры
glBindTexture(GL_TEXTURE_2D, textureID);
glEnable(GL_ALPHA_TEST); // проверка на элементы α-канала
//(не обязательно)
glAlphaFunc(GL_GREATER, 0.99); // задается тип уровня и его//если раскоменчено то желтое
//числовая граница
glEnableClientState(GL_VERTEX_ARRAY); //использование вектора
//координат
glEnableClientState(GL_TEXTURE_COORD_ARRAY); //использование
//вектора текстурных координат
glVertexPointer(3, GL_FLOAT, 0, svertix); //используем вектор координат
glTexCoordPointer(3, GL_FLOAT, 0, TexCord); //используем вектор
//текстурных координат
glDrawArrays(GL_TRIANGLE_FAN, 0, num);
glDisableClientState(GL_VERTEX_ARRAY);
glDisableClientState(GL_TEXTURE_COORD_ARRAY);
glDisable(GL_ALPHA_TEST);
 //отключение проверки α-канала

glDisable(GL_TEXTURE_2D);
// glPopMatrix();
}








