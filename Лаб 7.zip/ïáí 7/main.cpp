#include <windows.h>
#include <gl/gl.h>
#include "World.h"
#include "camera.h"
#include "Geom.h"
#include "Texture.h"
#include "Light.h"
#include <math.h>
LRESULT CALLBACK WindowProc(HWND, UINT, WPARAM, LPARAM);
void EnableOpenGL(HWND hwnd, HDC*, HGLRC*);
void DisableOpenGL(HWND, HDC, HGLRC);
float x;
float y;
float z;
//GLfloat light_position[] = { 5, 4, 5,  1 }; //������� ���������//���� ���� �� �������� ����� �� ���������
//GLfloat light_position[] = { 7, 4, 7,  1 }; //������� ���������,������ ����
//GLfloat light_spot_direction[] = {0, 1, 0}; // ������� ����

int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)
{
    WNDCLASSEX wcex;
    HWND hwnd;
    HDC hDC;
    HGLRC hRC;
    MSG msg;
    BOOL bQuit = FALSE;
    float theta = 0.0f;
    float thetaTriangle = 0.0f;

    /* register window class */
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_OWNDC;
    wcex.lpfnWndProc = WindowProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wcex.lpszMenuName = NULL;
    wcex.lpszClassName = "GLSample";
    wcex.hIconSm = LoadIcon(NULL, IDI_APPLICATION);
    if (!RegisterClassEx(&wcex))
        return 0;

    /* create main window */
    hwnd = CreateWindowEx(0,
                          "GLSample",
                          "OpenGL Sample",
                          WS_OVERLAPPEDWINDOW,
                          CW_USEDEFAULT,
                          CW_USEDEFAULT,
                          1200,
                          1000,
                          NULL,
                          NULL,
                          hInstance,
                          NULL);

    ShowWindow(hwnd, nCmdShow);
    /* enable OpenGL for the window */
    EnableOpenGL(hwnd, &hDC, &hRC);


    RECT rct;
    GetClientRect(hwnd,&rct);
    WndResize(rct.right,rct.bottom);

    Triangle RotTriangle;
    RotTriangle.index=1;
    LoadTextur("illum_back.png",&RotTriangle.index,GL_REPEAT,GL_REPEAT,GL_NEAREST);

    RectangleClass Floor;
    Floor.index=2;
    Floor.SvertFill(0,0,0,  10,0,0,  10,10,0, 0,10,0);
    LoadTextur("plitka.png",&Floor.index,GL_REPEAT,GL_REPEAT,GL_NEAREST);

    float hellotriangle [9] = {5,1,11,  3,3,11,  7,3,11 };

    RectangleClass wall;
    wall.SvertFill(0,0,0, 0,0,10, 10,0,10, 10,0,0);
    RectangleClass wall1;
    wall1.SvertFill(0,0,0,  0,10,0,  0,10,10, 0,0,10);
    RectangleClass wall2;
    wall2.SvertFill(0,0,10,  10,0,10,  10,10,10, 0,10,10);
    RectangleClass wall3;
    wall3.SvertFill(10,0,0,  10,10,0,  10,10,10, 10,0,10);
    RectangleClass top;
    top.SvertFill(0,10,0,  0,10,10, 10,10,10,  10,10,0);

    RectangleClass doublefloor;
    doublefloor.SvertFill(0,0,0,  10,0,0,  10,10,0, 0,10,0);

    Init_Light();
    EnableClarity();

    /* program main loop */
    while (!bQuit)
    {
        /* check for messages */
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
        {
            /* handle or dispatch messages */
            if (msg.message == WM_QUIT)
            {
                bQuit = TRUE;
            }
            else
            {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
        }
        else
        {
//            /* OpenGL animation code goes here */
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

            glPushMatrix();

            if (GetForegroundWindow()==hwnd)
                MoveCamera();
            Camera_Apply();
            glPushMatrix();
            ApplyLight(theta);
            rectangle(Floor,0.0f,0.0f,1.0f);//���
            DrawCube(9,9,0.5, 2, 1,1,1);
            DrawCube(1,9,0.5, 2, 1,1,1);
            DrawCube(1,1,0.5, 2, 1,1,1);
            DrawCube(9,1,0.5, 2, 1,1,1);
            float clarity = 1.0;
            for (int i=0;i<8;i++)
            {
                DrawPrisma(13,5*cos(M_PI_4*i)+5,5*sin(M_PI_4*i)+5,0.5,clarity);
                clarity-=0.1;
            }
            lin(0.0f, 0.0f, 0.0f,  0.0f, 0.0f, 5.0f,  0.0f,1.0f,0.0f);//z �������//���������� �� ������
            lin(0.0f, 0.0f, 0.0f,  0.0f, 5.0f, 0.0f,  0.0f,0.0f,1.0f);//y �����
            lin(0.0f, 0.0f, 0.0f,  5.0f, 0.0f, 0.0f,  1.0f,0.0f,0.0f);//x �������
            glPopMatrix();
            glPopMatrix();
            SwapBuffers(hDC);//������ �����
            theta += -0.01;
            thetaTriangle += 3.0f;
            Sleep (1);
        }
    }

    /* shutdown OpenGL */
    DisableOpenGL(hwnd, hDC, hRC);

    /* destroy the window explicitly */
    DestroyWindow(hwnd);

    return msg.wParam;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_CLOSE:
            PostQuitMessage(0);
        break;

        case WM_DESTROY:
            return 0;

        case WM_KEYDOWN:
        {
            switch (wParam)
            {
                case VK_ESCAPE:
                    PostQuitMessage(0);
                break;
            }
        }
        break;

        default:
            return DefWindowProc(hwnd, uMsg, wParam, lParam);
    }

    return 0;
}

void EnableOpenGL(HWND hwnd, HDC* hDC, HGLRC* hRC)
{
    PIXELFORMATDESCRIPTOR pfd;

    int iFormat;

    /* get the device context (DC) */
    *hDC = GetDC(hwnd);

    /* set the pixel format for the DC */
    ZeroMemory(&pfd, sizeof(pfd));

    pfd.nSize = sizeof(pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW |
                  PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 24;
    pfd.cDepthBits = 16;
    pfd.iLayerType = PFD_MAIN_PLANE;

    iFormat = ChoosePixelFormat(*hDC, &pfd);

    SetPixelFormat(*hDC, iFormat, &pfd);

    /* create and enable the render context (RC) */
    *hRC = wglCreateContext(*hDC);

    wglMakeCurrent(*hDC, *hRC);
}

void DisableOpenGL (HWND hwnd, HDC hDC, HGLRC hRC)
{
    wglMakeCurrent(NULL, NULL);
    wglDeleteContext(hRC);
    ReleaseDC(hwnd, hDC);
}

