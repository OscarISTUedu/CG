#pragma once

void LoadTextur(char *filename, GLuint *textureID, GLfloat swarp, GLfloat twarp, GLfloat filter);
void ShowBackround(GLuint textureID,int num,float* svertix,float* TexCord);
