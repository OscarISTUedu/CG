#pragma once
void Init_Light();
void Init_Material();
void ApplyLight(float theta);
void DrawPrisma(int count, float x,float y,float z, float transparency);
void EnableClarity();
