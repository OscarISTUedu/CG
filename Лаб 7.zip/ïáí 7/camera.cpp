#include <windows.h>
#include <gl/gl.h>
#include "camera.h"
#include <math.h>
#include <iostream>
#include "Geom.h"
using namespace std;
//float x,y,z;
//float Xrot,Zrot;
float cords [5];
struct SCamera camera={1,1,3, 1,1};


float* Camera_Apply(){

//    glRotatef(-camera.Xrot,1,0,0);
//    glRotatef(-camera.Yrot,0,1,0);
    glRotatef(-camera.Xrot,1,0,0);
    glRotatef(-camera.Zrot,0,0,1);
    glTranslatef(-camera.x, -camera.y, -camera.z);
//    GLfloat temp;
//    //��������� glRotatef(-camera.Xrot,1,0,0);
////    temp = light_spot_direction[1];
////    light_spot_direction[1]=light_spot_direction[1]*cos(-camera.Xrot)+light_spot_direction[2]*sin(-camera.Xrot);
////    light_spot_direction[2]=(-temp)*sin(-camera.Xrot)+light_spot_direction[2]*cos(-camera.Xrot);
//    temp = light_position[1];
//    light_position[1]=light_position[1]*cos(-camera.Xrot)+light_position[2]*sin(-camera.Xrot);
//    light_position[2]=-temp*sin(-camera.Xrot)+light_position[2]*cos(-camera.Xrot);
//    //��������� glRotatef(-camera.Yrot,0,1,0);
////    temp = light_spot_direction[0];
////    light_spot_direction[0]=light_spot_direction[0]*cos(-camera.Yrot)-light_spot_direction[2]*sin(-camera.Yrot);
////    light_spot_direction[2]=(temp)*sin(-camera.Yrot)+light_spot_direction[2]*cos(-camera.Yrot);
//    temp = light_position[0];
//    light_position[0]=light_position[0]*cos(-camera.Yrot)-light_position[2]*sin(-camera.Yrot);
//    light_position[2]=temp*sin(-camera.Yrot)+light_position[2]*cos(-camera.Yrot);
//    //��������� glTranslatef
////    light_spot_direction[0]+=-camera.x;
////    light_spot_direction[1]+=-camera.y;
////    light_spot_direction[2]+=-camera.z;
//    light_position[0]+=-camera.x;
//    light_position[1]+=-camera.y;
//    light_position[2]+=-camera.z;

cords[0]=camera.x;//ptr
cords[1]=camera.y;//ptr+1
cords[2]=camera.z;//ptr+2
cords[3]=camera.Xrot;//ptr+3
cords[4]=camera.Zrot;//ptr+4
return cords;
}

void Camera_Rotation(float xAngle,float zAngle){
//camera.Yrot+=yAngle;
//if( camera.Yrot<0) camera.Yrot +=360;
//if( camera.Yrot>360) camera.Yrot -=360;
//camera.Xrot+=xAngle;
//if( camera.Xrot<0) camera.Xrot =0;//����� ������
//if( camera.Xrot>180) camera.Xrot-=180;
camera.Zrot+=zAngle;
if( camera.Zrot<0) camera.Zrot +=360;
if( camera.Zrot>360) camera.Zrot -=360;
camera.Xrot+=xAngle;
if( camera.Xrot<-45) camera.Xrot =-45;//����� ������
if( camera.Xrot>180) camera.Xrot =180;
}

void Camer_AutoMoveByMouse(int centerX, int centerY, float speed){
ShowCursor(false);
POINT cur;
POINT base = {centerX,centerY};
GetCursorPos(&cur);
Camera_Rotation( (base.y - cur.y)/5,(base.x - cur.x)/5);
//Camera_Rotation( (base.x - cur.x)/5,(base.y - cur.y)/5);//���� ������ ������ �� �� ��� ����
SetCursorPos(base.x,base.y);
}

void Camera_MoveDirectional(int forwardMove, int rightMove, float speed)
{

    float ugol = -camera.Zrot/180*M_PI;//camera.Zrot - �������,ugol - �������
    if (forwardMove>0)//S
            ugol+=rightMove>0/*D*/ ? M_PI_4 :(rightMove<0/*A*/? -M_PI_4 :0);
    if (forwardMove<0)//W
            ugol+=M_PI + (rightMove>0 /*D*/? -M_PI_4 :(rightMove<0/*A*/ ? M_PI_4 :0));
    if (forwardMove==0)/*stand*/
        {
        if (rightMove==0) speed=0;
        ugol += rightMove > 0? M_PI_2 : -M_PI_2;/*D*/
        }
    if (speed!=0)
        {
        camera.x+= sin(ugol)*speed;//�� ������� ��������� ������ �� ����
        camera.y+= cos(ugol)*speed;//�� ������� ��������� ������ �� ����
        }
}


void MoveCamera()
    {
    Camera_MoveDirectional(
    GetKeyState('W')< 0 ? 1 : GetKeyState('S')< 0 ? -1 : 0,
    GetKeyState('D')< 0 ? 1 : GetKeyState('A')< 0 ? -1 : 0,0.1);
    Camer_AutoMoveByMouse(400,400,0.1);
    }

