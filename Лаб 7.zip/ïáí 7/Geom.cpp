#include "Geom.h"
#include "camera.h"
#include "Light.h"
#include "Texture.h"
#include <iostream>
#include <vector>
#include <math.h>
using namespace std;

void rectangleColored(RectangleClass obj,GLfloat red,GLfloat green,GLfloat blue,GLfloat x,GLfloat y, GLfloat z)
{
//    Init_Material();
    GLfloat normal_vert[]={
      0.0f,1.0f,0.0f,
      0.0f,1.0f,0.0f,
      0.0f,1.0f,0.0f,
      0.0f,1.0f,0.0f};
    glColor3f(red,green,blue); //����
    glEnableClientState(GL_VERTEX_ARRAY); //����������
    glEnableClientState(GL_NORMAL_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, obj.svertix); //������ ��������� � VBO
    glNormalPointer(GL_FLOAT,0,&normal_vert);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 4); //��������� ��������������
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
}

void rectangle(RectangleClass obj, GLfloat x, GLfloat y, GLfloat z)
{
    glColor3f(1,1,1);
//    Init_Material();
    GLfloat normal_vert[]={x,y,z, x,y,z, x,y,z, x,y,z};
//    GLfloat normal_vert[]= {0,0,30,  10,0,30,  10,10,30, 0,10,30};
    ShowBackround(obj.index,4,&obj.svertix[0],obj.TextFill(0,0,0 ,4,0,0, 4,4,0  ,0,4,0));
    glEnableClientState(GL_VERTEX_ARRAY); //����������
    glEnableClientState(GL_NORMAL_ARRAY);
    glVertexPointer(3, GL_FLOAT, 0, obj.svertix); //������ ��������� � VBO
    glNormalPointer(GL_FLOAT,0,&normal_vert);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 4); //��������� ��������������
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);

}

void lin(float x1,float y1,float z1,float x2,float y2,float z2,GLfloat red,GLfloat green,GLfloat blue)
{
//    Init_Material();
    glPushMatrix();
    glColor3f(red,green,blue);
    glBegin(GL_LINES);
    glVertex3f(x1, y1,z1);
    glVertex3f(x2, y2,z2);
    glEnd();
    glPopMatrix();
    glColor3f(1,1,1);
}


void triangleRotating (Triangle obj,GLfloat theta,GLfloat red,GLfloat green,GLfloat blue)
{
    GLfloat normal_vert[]={0,1,0, 0,1,0, 0,1,0, 0,1,0};
//    Init_Material();
    glPushMatrix();
    glColor3f(1,0,1);
    glRotatef(theta,0.0f + x ,1.0f + y,0.0f + z);
    if (GetKeyState('C')< 0) { x=0; y=0; z=0;}
    ShowBackround(obj.index,3,obj.SvertFill(0,0,-2, 2,0,0, 1.5,2,-0.5),obj.TextFill(0.8,0.8,0   ,0.2,0.8,0,   0.5,0.1,0));
    glVertexPointer(3, GL_FLOAT, 0, obj.svertix); //������ ��������� � VBO
    glEnableClientState(GL_VERTEX_ARRAY); //����������
    glEnableClientState(GL_NORMAL_ARRAY);
    glNormalPointer(GL_FLOAT,0,&normal_vert);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 3); //��������� ������������
    glPopMatrix();
    glColor3f(1,1,1);
    glDisableClientState(GL_VERTEX_ARRAY);

}

void triangleRotating (float svertix[],GLfloat theta,GLfloat red,GLfloat green,GLfloat blue)
{
//    Init_Material();
    glPushMatrix();
    glTranslatef(svertix[0],svertix[1],svertix[2]);
    glRotatef(theta,0.0f ,1.0f ,0.0f );
    glBegin(GL_TRIANGLES);
                glColor3f(1.0f, 0.0f, 0.0f);   glVertex3f(0,0,0);
                glColor3f(0.0f, 1.0f, 0.0f);   glVertex3f(-2,2,0);
                glColor3f(0.0f, 0.0f, 1.0f);   glVertex3f(2,2,0);
    glEnd();
    glTranslatef(-svertix[0],-svertix[1],-svertix[2]);
    glPopMatrix();
    glColor3f(1,1,1);
}

void DrawCube(GLfloat x,GLfloat y,GLfloat z,GLfloat k,float r,float g,float b){

GLfloat vertices[] = {
 -0.5f/k+x, -0.5f/k+y, -0.5f/k+z,
 0.5f/k+x, -0.5f/k+y, -0.5f/k+z,
 0.5f/k+x, 0.5f/k+y, -0.5f/k+z,
 -0.5f/k+x, 0.5f/k+y, -0.5f/k+z,
 -0.5f/k+x, -0.5f/k+y, 0.5f/k+z,
 0.5f/k+x, -0.5f/k+y, 0.5f/k+z,
 0.5f/k+x, 0.5f/k+y, 0.5f/k+z,
 -0.5f/k+x, 0.5f/k+y, 0.5f/k+z
};

GLuint indices[] = {
 0, 1, 2,
 2, 3, 0,

 1, 5, 6,
 6, 2, 1,

 7, 6, 5,
 5, 4, 7,

 4, 0, 3,
 3, 7, 4,

 4, 5, 1,
 1, 0, 4,

 3, 2, 6,
 6, 7, 3
};
GLfloat normals[] = {
 0.0f, 0.0f, -1.0f,
 0.0f, 0.0f, -1.0f,
 0.0f, 0.0f, -1.0f,
 0.0f, 0.0f, -1.0f,

 0.0f, 0.0f, 1.0f,
 0.0f, 0.0f, 1.0f,
 0.0f, 0.0f, 1.0f,
 0.0f, 0.0f, 1.0f,

 -1.0f, 0.0f, 0.0f,
 -1.0f, 0.0f, 0.0f,
 -1.0f, 0.0f, 0.0f,
 -1.0f, 0.0f, 0.0f,

 1.0f, 0.0f, 0.0f,
 1.0f, 0.0f, 0.0f,
 1.0f, 0.0f, 0.0f,
 1.0f, 0.0f, 0.0f,

 0.0f, -1.0f, 0.0f,
 0.0f, -1.0f, 0.0f,
 0.0f, -1.0f, 0.0f,
 0.0f, -1.0f, 0.0f,

 0.0f, 1.0f, 0.0f,
 0.0f, 1.0f, 0.0f,
 0.0f, 1.0f, 0.0f,
 0.0f, 1.0f, 0.0f
};
Init_Material();
glColor3f(r,g,b);
glEnableClientState(GL_VERTEX_ARRAY);
glEnableClientState(GL_NORMAL_ARRAY);
glVertexPointer(3, GL_FLOAT, 0, vertices);
glNormalPointer(GL_FLOAT, 0, normals);
glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, indices);
glDisableClientState(GL_VERTEX_ARRAY);
glDisableClientState(GL_NORMAL_ARRAY);
}

void DrawPrisma(int count, float x,float y,float z, float transparency) {

    glPushMatrix();
    glTranslatef(x,y,z);
    glScalef(1,1,1);
    vector<float> figure;
    vector<float> figureUP;
    vector<float> figureDOWN;
    float step = 2 * M_PI / count;//������� ������ �� 1 �������//��� 8//M_PI/4
    for (int i = 0; i < count; i++)
        {
            for (int z = 0; z < 2; z++)
            {
                figure.push_back(cos(step * i));//���
                figure.push_back(sin(step * i));
                figure.push_back(z);
                if (z == 0)//0 - ������ �����
                    {
                    figureDOWN.push_back(cos(step * i));
                    figureDOWN.push_back(sin(step * i));
                    figureDOWN.push_back(z);
                    }
                else//1 - ������� �����
                    {
                    figureUP.push_back(cos(step * i));
                    figureUP.push_back(sin(step * i));
                    figureUP.push_back(z);
                    }
            }

        }
    //����� ��������� ��������� �����//������ �����������
    figure.push_back(figure[0]);
    figure.push_back(figure[1]);
    figure.push_back(figure[2]);
    //������ �����������
    figure.push_back(figure[3]);
    figure.push_back(figure[4]);
    figure.push_back(figure[5]);

    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);

    glColor4f(0, 0, 1, transparency);
    glVertexPointer(3, GL_FLOAT, 0, figure.data());
    glNormalPointer(GL_FLOAT, 0, figure.data());
    glDrawArrays(GL_TRIANGLE_STRIP, 0, count*2 + 2);

    glColor4f(1, 1, 1, transparency);
    glVertexPointer(3, GL_FLOAT, 0, figureUP.data());
    glNormalPointer(GL_FLOAT, 0, figureUP.data());
    glDrawArrays(GL_POLYGON, 0, count);

    glVertexPointer(3, GL_FLOAT, 0, figureDOWN.data());
    glNormalPointer(GL_FLOAT, 0, figureDOWN.data());
    glDrawArrays(GL_POLYGON, 0, count);
    glColor4f(0, 0, 1, transparency);

    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
    glPopMatrix();
}





