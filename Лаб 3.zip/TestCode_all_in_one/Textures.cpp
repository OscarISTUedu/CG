#include <windows.h>
#include <gl/gl.h>
#include <stdio.h>
#include <stdlib.h>
#include "Buttons.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb-master/stb_image.h"
#include <iostream>
using namespace std;

float spriteXsize=640; //переменные с размерами текстуры и отдельного кадра
float spriteYsize=240;
float charsizey=80;
float charsizex=80;


void LoadTextur(char *filename, GLuint *textureID, GLfloat swarp, GLfloat twarp, GLfloat filter){
glPushMatrix();//tcnt - кол-во каналов
int twidth, thight, tcnt; //переменные ширины, высоты,
unsigned char *data=stbi_load(filename,&twidth,&thight,&tcnt,0);
// в поле filename прописывается имя
//файла “image.png”, а файл хранится в
//директории проекта
glGenTextures(1, textureID); //генерация текстуры
glBindTexture(GL_TEXTURE_2D, *textureID);
glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,swarp);//если координаты текстуры отличаются от координат примитива // по x //настройки
glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,twarp);//по y
glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,filter);//если размер текстуры и размер примитива отличаются //растяжение
glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,filter);//сжатие
glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, twidth, thight,
0, tcnt == 4 ? GL_RGBA : GL_RGB, GL_UNSIGNED_BYTE, data);

glBindTexture(GL_TEXTURE_2D, 0); //задание текстуры//чтобы эту текстура больше не зтрагивалась
stbi_image_free(data); //освобождение буфера
glPopMatrix();
}

void ShowBackround(GLuint textureID,float* svertix,float* TexCord){
glPushMatrix();
glTranslatef(250, 200, 0);
 // текстурные координаты
//изображения
glEnable(GL_TEXTURE_2D); //разрешение использования
//текстуры
glBindTexture(GL_TEXTURE_2D, textureID);
glEnable(GL_ALPHA_TEST); // проверка на элементы α-канала
//(не обязательно)
glAlphaFunc(GL_GREATER, 0.99); // задается тип уровня и его
//числовая граница
glEnableClientState(GL_VERTEX_ARRAY); //использование вектора
//координат
glEnableClientState(GL_TEXTURE_COORD_ARRAY); //использование
//вектора текстурных координат
glVertexPointer(2, GL_FLOAT, 0, svertix); //используем вектор координат
glTexCoordPointer(2, GL_FLOAT, 0, TexCord); //используем вектор
//текстурных координат
glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
glDisableClientState(GL_VERTEX_ARRAY);
glDisableClientState(GL_TEXTURE_COORD_ARRAY);
glDisable(GL_ALPHA_TEST);
 //отключение проверки α-канала
 glPopMatrix();
}

void HeroAnimation(GLuint textureID,float* svertix,float* TexCord,Hero* obj,float* frame,int SpriteLine,bool IsBack){
glPushMatrix();
if (*frame>7)
    {
    *frame=0;
    }

//SpriteLine - выбор анимации: 0-ходьба,1-прыжок,2-пригнутся
if (not(SpriteLine==-1))
{
    obj->left=(charsizex*(*frame))/spriteXsize; //вычисление координат кадра на изображении от
    obj->right=obj->left+(charsizex/spriteXsize); //номера кадра
    obj->top=(charsizey*SpriteLine)/spriteYsize;
    obj->bottom=obj->top+(charsizey/spriteYsize);
}
else
    {//кадр когда герой стоит (не анимация)
        obj->left=(charsizex*0)/spriteXsize; //вычисление координат кадра на изображении от
        obj->right=obj->left+(charsizex/spriteXsize); //номера кадра
        obj->top=(charsizey*0)/spriteYsize;
        obj->bottom=obj->top+(charsizey/spriteYsize);
    }
TexCord[1] = TexCord[3] = obj->bottom; // запись в вектор текстурных координат
TexCord[5] = TexCord[7] = obj->top;
if (IsBack)
{
        TexCord[2] = TexCord[4] = obj->left;
        TexCord[0] = TexCord[6] = obj->right;
}
else
    {
        TexCord[2] = TexCord[4] = obj->right;
        TexCord[0] = TexCord[6] = obj->left;
    }
//glTranslatef(250, 200, 0);
 // текстурные координаты
//изображения
glEnable(GL_TEXTURE_2D); //разрешение использования
//текстуры
glBindTexture(GL_TEXTURE_2D, textureID);
glEnable(GL_ALPHA_TEST); // проверка на элементы α-канала
//(не обязательно)
glAlphaFunc(GL_GREATER, 0.99); // задается тип уровня и его
//числовая граница
glEnableClientState(GL_VERTEX_ARRAY); //использование вектора
//координат
glEnableClientState(GL_TEXTURE_COORD_ARRAY); //использование
//вектора текстурных координат
glVertexPointer(2, GL_FLOAT, 0, svertix); //используем вектор координат
glTexCoordPointer(2, GL_FLOAT, 0, TexCord); //используем вектор
//текстурных координат
glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
glDisableClientState(GL_VERTEX_ARRAY);
glDisableClientState(GL_TEXTURE_COORD_ARRAY);
glDisable(GL_ALPHA_TEST);
 //отключение проверки α-канала
 glPopMatrix();
}





