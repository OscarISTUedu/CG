#include <windows.h>
#include <gl/gl.h>
#include <stdio.h>
#include <stdlib.h>
#include "Buttons.h"
#define STB_IMAGE_IMPLEMENTATION
#include "../stb-master/stb_image.h"

void LoadTextur(char *filename, GLuint *textureID, GLfloat swarp, GLfloat twarp, GLfloat filter){

int twidth, thight, tcnt; //переменные ширины, высоты,
unsigned char *data=stbi_load(filename,&twidth,&thight,&tcnt,0);
// в поле filename прописывается имя
//файла “image.png”, а файл хранится в
//директории проекта
glGenTextures(1, textureID); //генерация текстуры
glBindTexture(GL_TEXTURE_2D, *textureID);

glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,swarp); //настройки
glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,twarp);
glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,filter);
glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,filter);


glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, twidth, thight,
0, tcnt == 4 ? GL_RGBA : GL_RGB, GL_UNSIGNED_BYTE, data);

glBindTexture(GL_TEXTURE_2D, 0); //задание текстуры
stbi_image_free(data); //освобождение буфера

}

void ShowBackround(GLuint textureID){

static float svertix[]= {0,0, 648,0, 648,246, 0,246}; //вектор текстурируемого
//многоугольника
static float TexCord[]= {0,1, 1,1, 1,0, 0,0}; // текстурные координаты
 // текстурные координаты
//изображения
glEnable(GL_TEXTURE_2D); //разрешение использования
//текстуры
glBindTexture(GL_TEXTURE_2D, textureID);
//glEnable(GL_ALPHA_TEST); // проверка на элементы α-канала
//(не обязательно)
//glAlphaFunc(GL_GREATER, 0.99); // задается тип уровня и его
//числовая граница
glEnableClientState(GL_VERTEX_ARRAY); //использование вектора
//координат
glEnableClientState(GL_TEXTURE_COORD_ARRAY); //использование
//вектора текстурных координат





glVertexPointer(2, GL_FLOAT, 0, svertix); //используем вектор координат
glTexCoordPointer(2, GL_FLOAT, 0, TexCord); //используем вектор
//текстурных координат
glDrawArrays(GL_TRIANGLE_FAN, 0, 4);

glDisableClientState(GL_VERTEX_ARRAY);
glDisableClientState(GL_TEXTURE_COORD_ARRAY);

 //отключение проверки α-канала
}
