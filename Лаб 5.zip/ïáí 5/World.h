#pragma once
void WndResize(int x, int y);


