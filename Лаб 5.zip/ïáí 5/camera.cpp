#include <windows.h>
#include <gl/gl.h>
#include "camera.h"
#include <math.h>
#include <iostream>
using namespace std;
//float x,y,z;
//float Xrot,Yrot;
struct SCamera camera={0,1.3,5, 1,1};
void Camera_Apply(){
glRotatef(-camera.Xrot,1,0,0);
glRotatef(-camera.Yrot,0,1,0);
glTranslatef(-camera.x, -camera.y, -camera.z);
}

void Camera_Rotation(float xAngle, float yAngle){
camera.Yrot+=yAngle;
if( camera.Yrot<0) camera.Yrot +=360;
if( camera.Yrot>360) camera.Yrot -=360;
camera.Xrot+=xAngle;
if( camera.Xrot<-45) camera.Xrot =-45;//����� ������
if( camera.Xrot>180) camera.Xrot =180;
}

void Camer_AutoMoveByMouse(int centerX, int centerY, float speed){

//if (GetKeyState(VK_UP)<0) Camera_Rotation(speed,0);
//if (GetKeyState(VK_DOWN)<0) Camera_Rotation(-speed,0);
//if (GetKeyState(VK_RIGHT)<0) Camera_Rotation(0,-speed);
//if (GetKeyState(VK_LEFT)<0) Camera_Rotation(0,speed);
ShowCursor(false);
POINT cur;
POINT base = {centerX,centerY};
GetCursorPos(&cur);
Camera_Rotation( (base.y - cur.y)/5,(base.x - cur.x)/5);
SetCursorPos(base.x,base.y);
}

void Camera_MoveDirectional(int forwardMove, int rightMove, float speed)
{

    float ugol = camera.Yrot/180*M_PI;//camera.Zrot - �������,ugol - �������
    if (forwardMove>0)//W
            ugol+=rightMove>0/*D*/ ? M_PI_4 :(rightMove<0/*A*/? -M_PI_4 :0);
    if (forwardMove<0)//S
            ugol+=M_PI + (rightMove>0 /*D*/? -M_PI_4 :(rightMove<0/*A*/ ? M_PI_4 :0));
    if (forwardMove==0)/*stand*/ {
        ugol +=rightMove > 0/*D*/? M_PI_2 : -M_PI_2;
        if (rightMove==0) speed=0;
    }
    if (speed!=0){
        camera.x+= sin(ugol)*speed;
        camera.z+= cos(ugol)*speed;
    }
}


void MoveCamera()
    {
    Camera_MoveDirectional(
    GetKeyState('S')< 0 ? 1 : GetKeyState('W')< 0 ? -1 : 0,
    GetKeyState('D')< 0 ? 1 : GetKeyState('A')< 0 ? -1 : 0,0.1);
    Camer_AutoMoveByMouse(400,400,1);
    }

