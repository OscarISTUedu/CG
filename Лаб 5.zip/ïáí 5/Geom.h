#pragma once
#include <gl/gl.h>
#include <iostream>
#include <vector>
using namespace std;

extern float x;
extern float y;
extern float z;

class Triangle
{
public:
    float textcord[9];
    float svertix[9];
    GLuint index;
float* TextFill(float a0,float a1,float a2,float a3,float a4,float a5,float a6,float a7,float a8)
{
    textcord[0]=a0;
    textcord[1]=a1;
    textcord[2]=a2;
    textcord[3]=a3;
    textcord[4]=a4;
    textcord[5]=a5;
    textcord[6]=a6;
    textcord[7]=a7;
    textcord[8]=a8;
    return &textcord[0];
}

float* SvertFill(float a0,float a1,float a2,float a3,float a4,float a5,float a6,float a7,float a8)
{
    svertix[0]=a0;
    svertix[1]=a1;
    svertix[2]=a2;
    svertix[3]=a3;
    svertix[4]=a4;
    svertix[5]=a5;
    svertix[6]=a6;
    svertix[7]=a7;
    svertix[8]=a8;
    return &svertix[0];
}
};

class RectangleClass
{
public:
    float textcord[12];
    float svertix[12];
    GLuint index;
float* TextFill(float a0,float a1,float a2,float a3,float a4,float a5,float a6,float a7,float a8,float a9,float a10,float a11)
{
    textcord[0]=a0;
    textcord[1]=a1;
    textcord[2]=a2;
    textcord[3]=a3;
    textcord[4]=a4;
    textcord[5]=a5;
    textcord[6]=a6;
    textcord[7]=a7;
    textcord[8]=a8;
    textcord[9]=a9;
    textcord[10]=a10;
    textcord[11]=a11;
    return &textcord[0];
}

float* SvertFill(float a0,float a1,float a2,float a3,float a4,float a5,float a6,float a7,float a8,float a9,float a10,float a11)
{
    svertix[0]=a0;
    svertix[1]=a1;
    svertix[2]=a2;
    svertix[3]=a3;
    svertix[4]=a4;
    svertix[5]=a5;
    svertix[6]=a6;
    svertix[7]=a7;
    svertix[8]=a8;
    svertix[9]=a9;
    svertix[10]=a10;
    svertix[11]=a11;
    return &svertix[0];
}
};

void lin(float x1,float y1,float z1,float x2,float y2,float z2,GLfloat red,GLfloat green,GLfloat blue);
void rectangle(RectangleClass obj,GLfloat red,GLfloat green,GLfloat blue);
void triangleRotating (Triangle obj,GLfloat theta,GLfloat red,GLfloat green,GLfloat blue);
void triangleRotating (float* svertix,GLfloat theta,GLfloat red,GLfloat green,GLfloat blue);

