#pragma once
#define nameLen 20
#define winWidth 1200
#define winHeight 700
#include <iostream>
#include <vector>
using namespace std;

class Button
    {
        public:
    char name[nameLen]; // ����� ����� ������
    float vert[8]; // 4 ������� �� 2 ����������
    float buffer[50*nameLen]; // ��� ��������� ����������
    int num_quads; //��� ����������
    float textPosX,textPosY,textS; // ���������� ������������ ������ � ���������� ����������
    char isHovered,isDowned;
    int ButtonIdentificator;
    };

    class Hero
    {
        public:
    float x=1000;
    float y=100;
    float dx=10;
    float dy=10;
    float left=0;
    float right=0;
    float top=0;
    float bottom=0;
    float svertix[8];
    float TexCord[8]={0,1,1,1,1,0,0,0};
    bool DirectRight=true;
    void SvertixFill(GLint width,GLint heigh)
    {
        svertix[0]=0;
        svertix[1]=0;
        svertix[2]=width;
        svertix[3]=0;
        svertix[4]=width;
        svertix[5]=heigh;
        svertix[6]=0;
        svertix[7]=heigh;
    }
    };

    class Tile
    {
        public:
    float vert[8];
    int TileIdentificator;
    float svertix[8];
    float TexCord[8];
    GLuint image;
    void SvertixFill(GLuint width,GLuint heigh,float x,float y)
    {
        svertix[0]=x;
        svertix[1]=y;
        svertix[2]=width+x;
        svertix[3]=y;
        svertix[4]=width+x;
        svertix[5]=heigh+y;
        svertix[6]=x;
        svertix[7]=heigh+y;
    }
    void TexCordFill()
    {
        TexCord[0]=0;
        TexCord[1]=1;
        TexCord[2]=1;
        TexCord[3]=1;
        TexCord[4]=1;
        TexCord[5]=0;
        TexCord[6]=0;
        TexCord[7]=0;
    }

    };
extern int indTile;
extern vector <GLuint> TEXTURES;
extern vector <Tile> tiles;
extern bool DirectRight;
extern float charsizey;
extern float charsizex;
extern int TopBorder;//  672      //�������� �������� �����������
extern int RightBorder;// 1115
extern float const gravity;
extern int btnCnt;
extern Button *btn;
extern float MouseX,MouseY;
extern int gameState;
extern GLuint SpriteSheet;
extern GLuint Animate;
extern GLuint Platform;
extern int winstate;
extern int tileCnt;

int AddButton(int Identificator,char *name, float x, float y, float width, float height, float textS);
void ShowButton(int buttonId);
void ShowMenu();
char MouseInButton(int buttonId,float x,float y);
int MouseMove(float x,float y);
int DownButton ();
int UpButton ();
void Menu_Clear();
void MouseDown();
char *Menu_GetButtonName(int buttonID);
void Init_menu();
void LoadTextur(char *filename, GLuint *textureID, GLfloat swarp, GLfloat twarp, GLfloat filter);
void ShowBackround(GLuint textureID,float* svertix,float* TexCord);
void HeroShow(Hero *obj,int SpriteLine);
void HeroAnimation(GLuint textureID,Hero* obj,float* frame,int SpriteLine,GLint width,GLint height);
void HeroMove(Hero* obj);
bool ReflectX (float *da, float *a, BOOL cond, float wall);
bool ReflectY (float *da, float *a, BOOL cond, float wall);
Hero* GetObject();
bool OnFloor(Hero* obj);
void CheckX(float leftwall,float rightwall,Hero*  obj);
void CheckY(Hero*  obj);
void rectangle(float x,float y,float width,float height,GLfloat red,GLfloat green,GLfloat blue);
void AddTile(/*int tileId, */float x, float y, float width, float height,GLuint img);
void TileShow(int tileId);
void Collision(Tile* wall,Hero* fox);
void PrintArr(float* arr);
void InitMap();
void TileSelect(unsigned int tileId,int i,int j);
bool InBox(Tile* box,float x,float y);
void printCords (Hero* obj,string str);
