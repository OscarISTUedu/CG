#include <windows.h>
#include <gl/gl.h>
#include <stdio.h>
#include <stdlib.h>
#include "Buttons.h"
#include <iostream>
#include <typeinfo>
#include <bits/stdc++.h>
using namespace std;

int tileCnt;
vector <Tile> tiles;

int tilewidth = 100;
int tileheigh = 100;
int indTile = -1;

string TileMap[] = {
//0123456789AB   →i
 "ZZZ4ZZZZZZZZ",//6
 "ZZZZZZ333ZZZ",//5
 "Z44ZZZZZZZZZ",//4
 "Z44ZZZ4ZZZZZ",//3
 "Z44ZZZZZZ4ZZ",//2
 "ZZZ333ZZZZZZ",//1
 "ZZZZZZZZZZZZ"};//0
                //j↑




void AddTile(/*int tileId, */float x, float y, float width, float height,GLuint img)
{
    tileCnt++;
    Tile FreshTile;
    float *vert = FreshTile.vert;
    vert[0]=vert[6]=x;
    vert[2]=vert[4]=x+width;
    vert[1]=vert[3]=y;
    vert[5]=vert[7]=y+height;
    FreshTile.TexCordFill();
    FreshTile.TileIdentificator=tileCnt;
    FreshTile.image=img;
    tiles.push_back(FreshTile);
}
void TileShow(int tileId)
{
 glPushMatrix();
 glColor3f(1.0f,1.0f,1.0f);
 Tile* obj=&tiles[tileId];
 int width = obj->vert[2]-obj->vert[0];
 int height = obj->vert[5]-obj->vert[1];
 obj->SvertixFill(width,height,obj->vert[0],obj->vert[1]);
 obj->TexCordFill();
 ShowBackround(obj->image,obj->svertix,obj->TexCord);
 glPopMatrix();
}

void InitMap()
{
    vector <int> elements;
    vector <int> blocks;
    vector <int> textures;
    bool flag=false;
    bool order=true;
    int WidthIterator = winWidth/tilewidth;
    int HeighIterator = winHeight/tileheigh;
    for (int i=HeighIterator-1;i>=0;i--)//начал с конца т.к отрисовка начинатеся с левого нижнего угла
//а стандартный перебор по for идет с левого верхнего угла
    {
        for (int j=WidthIterator;j>=0;j--)
        {
            if (TileMap[i][j]!='Z')
            {
                if ((int(TileMap[i][j]))!=0)
                {
                    elements.push_back(j);// на четных местах
                    elements.push_back(i);// на нечетных местах
                    textures.push_back(int(TileMap[i][j])-'0');
                }
            }
        }
    }
    for (int h=0;h<elements.size();h++)//2
        {
            if ((h%2==0)&&(elements[h]!=-1))//смотрим повтояющиеся j и записываем их i в blocks //(на четных местах) j-"длинна"
            {
            blocks.push_back(elements[h+1]);
                for (int k=0;k<elements.size();k+=2)
                {
                    if ((h!=k)&&(elements[h]==elements[k])&&(textures[h/2]==textures[k/2])&&(elements[k]!=-1))
                    {
                        blocks.push_back(elements[k+1]);
                    }

                }
                if (blocks.size()>1)//добавляем только тайлы из 2 и более блоков
                {
                    sort(begin(blocks), end(blocks));
                    for (int z=0;z<blocks.size();z++)//проверяем что блоки идут друг за другом
                    {
                        if (!(blocks[z+1]-blocks[z]==1))
                            order=false;
                            break;

                    }
                    if (order)
                    {
                        AddTile(elements[h]*tilewidth,(*(min_element(begin(blocks), end(blocks))))*tileheigh,tilewidth,(blocks.size())*tileheigh,TEXTURES[textures[h/2]]);
                         for (int m=0;m<elements.size();m++)
                            {
                                if (m%2==0)
                                {

                                    if ((elements[m]==elements[h])&&(h!=m))
                                    {
                                        elements[m]=-1;
                                        elements[m+1]=-1;
                                        m++;
                                    }
                                }
                            }
                        elements[h]=-1;
                        elements[h+1]=-1;
                    }
                }
                blocks.clear();
                order=true;
            }
        }
order=true;
    for (int h=1;h<elements.size();h++)//1
        {
            if ((h%2!=0)&&(elements[h]!=-1))//смотрим повтояющиеся i и записываем их j в blocks //(на нечетных местах) i-"высота"
            {
            blocks.push_back(elements[h-1]);
                for (int k=0;k<elements.size();k++)
                {
                    if ((k%2!=0)&&(h!=k)&&(elements[h]==elements[k])&&(textures[(h-1)/2]==textures[(k-1)/2])&&(elements[k]!=-1))
                    {
                        blocks.push_back(elements[k-1]);
                    }
                }
            if (blocks.size()>1)//добавляем только тайлы из 2 и более блоков
                {
                   sort(begin(blocks), end(blocks));
                    for (int z=0;z<blocks.size();z++)//проверяем что блоки идут друг за другом
                    {
                        if (!(blocks[z+1]-blocks[z]==1))
                            order=false;
                            break;
                    }
                    if (order)
                    {
                        AddTile((*(min_element(begin(blocks), end(blocks))))*tilewidth,elements[h]*tileheigh,(blocks.size())*tilewidth,tileheigh,TEXTURES[textures[(h-1)/2]]);
                         for (int m=0;m<elements.size();m++)
                            {
                                if (m%2!=0)
                                {

                                    if ((elements[m]==elements[h])&&(h!=m))
                                    {
                                        elements[m]=-1;
                                        elements[m-1]=-1;
                                        m++;
                                    }
                                }
                            }
                        elements[h]=-1;
                        elements[h-1]=-1;
                    }
                }
            blocks.clear();

            }
        }
    for (int u=0;u<elements.size();u++)
    {
        if (elements[u]!=-1)
        {
            AddTile(elements[u]*tilewidth,elements[u+1]*tileheigh,tilewidth,tileheigh,TEXTURES[textures[u/2]]);
            u++;
        }
    }
    elements.clear();
    textures.clear();
    blocks.clear();
}

void Collision(Tile* wall,Hero* fox)
{
//    vert[0]=vert[6]=x;
//    vert[2]=vert[4]=x+width;
//    vert[1]=vert[3]=y;
//    vert[5]=vert[7]=y+height;
//    player1 = wall; player2 = fox
if (InBox(wall,fox->x,fox->y+fox->dy)&&
    (fox->x + charsizex > wall->vert[0])&&(fox->x < wall->vert[2]))//чтобы не пропрыгивать через платформу
{
    if ((wall->vert[1] - charsizey > 0)&&(fox->dy>0)&&(fox->y<=wall->vert[1]))
    {
    fox->y = wall->vert[1]-charsizey;
    fox->dy=0;
    return;
    }
}

if (InBox(wall,fox->x+fox->dx,fox->y))//герой идёт слева на право
    {
    if ((fox->y>=wall->vert[1])&&(wall->vert[5]>fox->y+charsizey)&&(fox->dx>0))
        {
            fox->x = wall->vert[0]-charsizex;
        }
    if ((fox->x<wall->vert[0])&&(fox->x+charsizex >wall->vert[0]))//чтобя при прыжке по диагонале вдоль блока край персонажа не зацеплял край тайла
        {
            fox->x = wall->vert[0]-charsizex;
        }

    }


if (InBox(wall,fox->x+fox->dx,fox->y))//герой идёт справа на лево
    {
        if ((fox->y>=wall->vert[1])&&(wall->vert[5]>fox->y+charsizey)&&(fox->dx<0))
        {
        fox->x = wall->vert[2];
        }
        if ((fox->x<wall->vert[2])&&(fox->x+charsizex>wall->vert[2]))//чтобя при прыжке по диагонале вдоль блока край персонажа не зацеплял край тайла
        {
           fox->x = wall->vert[2];
        }
    }


if ((InBox(wall,fox->x,fox->y+fox->dy))&&
    (fox->x + charsizex > wall->vert[0])&&(fox->x < wall->vert[2]))//чтобы стоять на блоке
    {
        if (fox->y>wall->vert[5])
        {
            fox->y = wall->vert[5];
            fox->dy=0;
        }
    }

}



bool InBox(Tile* box,float x,float y)//x,y позиция героя
{
    if (box->vert[0]< x + charsizex &&
    box->vert[2] > x &&
    box->vert[1] < y + charsizey &&
    box->vert[5] > y)
    {
        return true;
    }

    return false;
}

  void PrintArr(float* arr)
    {
        for (int i=0;i<8;i++)
        {
            cout<<arr[i]<<endl;
        }
    }
